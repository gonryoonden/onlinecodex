#!/usr/bin/env python3
"""Unified CLI for image-to-editable-ppt image generation or editing.

The CLI prefers local Codex OAuth auth when ~/.codex/auth.json is available.
If Codex auth is missing, it falls back to OpenAI-compatible API credentials
from the environment or ~/.editppt/config.yaml.
"""

from __future__ import annotations

import argparse
import base64
import json
import mimetypes
import os
from pathlib import Path
import random
import re
import socket
import sys
import time
from typing import Any, Dict, Iterable, List, Optional, Tuple
from urllib import error, request

DEFAULT_MODEL = "gpt-image-2.5-sunburst"
DEFAULT_SIZE = "auto"
DEFAULT_QUALITY = "auto"
DEFAULT_BACKGROUND = "auto"
DEFAULT_OUTPUT_EXTENSION = "png"
DEFAULT_OUTPUT_PATH = "output/imagegen/output.png"
DEFAULT_TIMEOUT = 600
DEFAULT_CODEX_MAX_RETRIES = 4
DEFAULT_CODEX_RETRY_BASE_DELAY_SECONDS = 0.2
GPT_IMAGE_MODEL_PREFIX = "gpt-image-"

ALLOWED_LEGACY_SIZES = {"1024x1024", "1536x1024", "1024x1536", "auto"}
ALLOWED_QUALITIES = {"low", "medium", "high", "xhigh", "max", "auto"}

GPT_IMAGE_2_MIN_PIXELS = 655_360
GPT_IMAGE_2_MAX_PIXELS = 8_294_400
GPT_IMAGE_2_MAX_EDGE = 3840
GPT_IMAGE_2_MAX_RATIO = 3.0

MAX_IMAGE_BYTES = 50 * 1024 * 1024
DEFAULT_CONFIG_HOME = "~/.editppt"
DEFAULT_CODEX_AUTH_FILE = "~/.codex/auth.json"
DEFAULT_CODEX_IMAGES_BASE_URL = "https://chatgpt.com/backend-api/codex"
ENV_FIELDS = ("OPENAI_API_KEY", "OPENAI_BASE_URL", "IMAGE_TO_EDITABLE_PPT_IMAGE_MODEL")
MAX_CODEX_RESPONSE_BYTES = 64 * 1024 * 1024
MAX_CODEX_BASE64_CHARS = 64 * 1024 * 1024
CHATGPT_AUTH_CLAIM = "https://api.openai.com/auth"
CHATGPT_ACCOUNT_ID_CLAIM = "chatgpt_account_id"

IMAGE_HELP_EPILOG = """\
Backend selection:
  Codex OAuth: uses ~/.codex/auth.json or CODEX_AUTH_FILE.
  API fallback: uses OPENAI_API_KEY, OPENAI_BASE_URL, and
  IMAGE_TO_EDITABLE_PPT_IMAGE_MODEL from the environment or ~/.editppt/config.yaml.

Setup:
  codex login
  editppt config --api-key "your-api-key" --model gpt-image-2.5-sunburst
  editppt config --api-key "your-api-key" --base-url https://example.test/v1 --model openai/gpt-image-2.5-sunburst

Input image rules:
  generate creates a new image from prompt only.
  edit passes each --image as an edit target, visual reference, or supporting input.

Parameter surface:
  Public image parameters are model, prompt, size, and quality. Codex OAuth
  requests also set background=auto to match Codex built-in image generation.
  Edit requests also pass the input images and optional mask. Local controls
  such as --out, --force, --dry-run, and --timeout are not image API parameters.

Slide reconstruction patterns:
  Clean base: use edit --image <source.png>; preserve source composition,
  perspective, object positions, colors, lighting, material, and background identity.
  Asset sheet: use edit --image <source.png>; separate exact existing foreground
  bitmap objects on a flat chroma-key background with generous spacing. Choose
  a key color absent from the assets and far from their main fills, strokes,
  highlights, and shadows; cyan, green, magenta, red, or orange are examples,
  not fixed defaults.
  Formula assets: use editppt formula render-latex, not editppt image.

Output:
  Write outputs under the page directory when used in a deck run. Record selected
  images with editppt image import, then use process-sheet when asset-sheet splitting is needed.
"""

GENERATE_HELP_EPILOG = """\
Backend:
  Uses Codex OAuth when available, otherwise API fallback from ~/.editppt/config.yaml
  or environment variables.

Use for:
  New supporting images that do not need to preserve an existing slide object.

Examples:
  editppt image generate --prompt "flat blue cloud icon, no text" --out pages/page_001/assets/cloud.png
  editppt image generate --prompt-file prompt.txt --size 1536x1024 --quality high --out output.png
"""

EDIT_HELP_EPILOG = """\
Backend:
  Uses Codex OAuth when available, otherwise API fallback from ~/.editppt/config.yaml
  or environment variables.

Use for:
  Background cleanup, clean base creation, foreground icon extraction, and
  source-faithful asset sheets. Pass the original slide through --image so the
  model receives it as the edit target and strict visual reference.

Prompt patterns:
  Clean base: preserve source canvas ratio, composition, perspective, object
  positions, colors, lighting, texture, and background identity; remove the
  foreground text/objects that will be rebuilt.
  Asset sheet: extract exact existing non-text foreground objects from the
  source into a sparse chroma-key sheet; preserve shape, stroke geometry, color,
  proportions, internal cutouts, and visual identity. Choose a key color absent
  from the target objects and far from their main fills, strokes, highlights,
  and shadows; cyan, green, magenta, red, or orange are examples, not fixed
  defaults.

Examples:
  editppt image edit --image pages/page_001/source.png --prompt-file clean-base.prompt.txt --out pages/page_001/assets/clean-base.png
  editppt image edit --image pages/page_001/source.png --prompt-file asset-sheet.prompt.txt --out pages/page_001/assets/asset-sheet.png
  editppt image edit --image source.png --image style.png --prompt "Use source as target and style as supporting reference" --out out.png
"""


def _die(message: str, code: int = 1) -> None:
    print(f"Error: {message}", file=sys.stderr)
    raise SystemExit(code)


def _warn(message: str) -> None:
    print(f"Warning: {message}", file=sys.stderr)


def _runtime_home() -> Path:
    return Path(os.getenv("EDITPPT_CONFIG_HOME", DEFAULT_CONFIG_HOME)).expanduser()


def _runtime_env_path() -> Path:
    return _runtime_home() / "config.yaml"


def _load_runtime_env() -> None:
    path = _runtime_env_path()
    if not path.exists():
        return
    try:
        import yaml
    except ImportError as exc:
        _die(
            "PyYAML is required to read ~/.editppt/config.yaml. "
            "Reinstall editppt with pipx so package dependencies are installed."
        )
    data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    if not isinstance(data, dict):
        _die(f"Invalid config file: {path}")
    for key, value in data.items():
        if key not in ENV_FIELDS or os.getenv(key):
            continue
        os.environ[key] = str(value)


def _default_model() -> str:
    return os.getenv("IMAGE_TO_EDITABLE_PPT_IMAGE_MODEL", DEFAULT_MODEL)


def _api_base_url() -> Optional[str]:
    return os.getenv("OPENAI_BASE_URL") or None


def _api_target_label() -> str:
    base_url = _api_base_url()
    if base_url:
        return f"OpenAI-compatible proxy (OPENAI_BASE_URL={base_url})"
    return "official OpenAI API (OPENAI_BASE_URL unset)"


def _codex_auth_file() -> Path:
    return Path(os.getenv("CODEX_AUTH_FILE", DEFAULT_CODEX_AUTH_FILE)).expanduser()


def _decode_jwt_payload(token: str) -> Dict[str, Any]:
    parts = token.split(".")
    if len(parts) < 2:
        return {}
    payload = parts[1] + "=" * (-len(parts[1]) % 4)
    try:
        raw = base64.urlsafe_b64decode(payload.encode("ascii"))
        data = json.loads(raw.decode("utf-8"))
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def _infer_codex_account_id(tokens: Dict[str, Any]) -> Optional[str]:
    account_id = tokens.get("account_id")
    if isinstance(account_id, str) and account_id.strip():
        return account_id.strip()

    id_token = tokens.get("id_token")
    if not isinstance(id_token, str) or not id_token.strip():
        return None
    auth_claim = _decode_jwt_payload(id_token).get(CHATGPT_AUTH_CLAIM)
    if not isinstance(auth_claim, dict):
        return None
    chatgpt_account_id = auth_claim.get(CHATGPT_ACCOUNT_ID_CLAIM)
    if isinstance(chatgpt_account_id, str) and chatgpt_account_id.strip():
        return chatgpt_account_id.strip()
    return None


def _load_codex_auth() -> Optional[Tuple[str, Optional[str]]]:
    path = _codex_auth_file()
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None
    tokens = data.get("tokens")
    if not isinstance(tokens, dict):
        return None
    token = tokens.get("access_token")
    if isinstance(token, str) and token.strip():
        return token.strip(), _infer_codex_account_id(tokens)
    return None


def _load_codex_access_token() -> Optional[str]:
    auth = _load_codex_auth()
    return auth[0] if auth else None


def _codex_available() -> bool:
    return _load_codex_access_token() is not None


def _codex_base_url() -> str:
    raw = (
        os.getenv("CODEX_IMAGES_BASE_URL")
        or DEFAULT_CODEX_IMAGES_BASE_URL
    ).strip()
    if not raw:
        return DEFAULT_CODEX_IMAGES_BASE_URL
    if re.fullmatch(r"https?://chatgpt\.com/backend-api(?:/codex)?(?:/v1)?/?", raw, re.I):
        return DEFAULT_CODEX_IMAGES_BASE_URL
    return raw.rstrip("/")


def _codex_image_url(operation: str) -> str:
    endpoint = "images/edits" if operation == "edit" else "images/generations"
    return f"{_codex_base_url()}/{endpoint}"


def _guess_mime(path: Path) -> str:
    mime, _ = mimetypes.guess_type(str(path))
    if mime and mime.startswith("image/"):
        return mime
    suffix = path.suffix.lower()
    if suffix in {".jpg", ".jpeg"}:
        return "image/jpeg"
    if suffix == ".webp":
        return "image/webp"
    return "image/png"


def _image_to_data_url(path: Path) -> str:
    data = path.read_bytes()
    encoded = base64.b64encode(data).decode("ascii")
    return f"data:{_guess_mime(path)};base64,{encoded}"


def _codex_image_reference(path: Path) -> Dict[str, str]:
    return {"image_url": _image_to_data_url(path)}


def _codex_image_body(
    *,
    prompt: str,
    image_paths: List[Path],
    mask_path: Optional[Path],
    model: str,
    size: str,
    quality: str,
) -> Dict[str, Any]:
    body: Dict[str, Any] = {
        "prompt": prompt,
        "model": model,
        "size": size,
        "quality": quality,
        "background": DEFAULT_BACKGROUND,
    }
    if image_paths:
        body["images"] = [_codex_image_reference(path) for path in image_paths]
    if mask_path:
        body["mask"] = _codex_image_reference(mask_path)
    return body


def _codex_retry_delay(attempt: int) -> float:
    exp = 2 ** max(attempt - 1, 0)
    jitter = random.uniform(0.9, 1.1)
    return DEFAULT_CODEX_RETRY_BASE_DELAY_SECONDS * exp * jitter


def _should_retry_codex_http(status: int) -> bool:
    return 500 <= status <= 599


def _format_attempts(attempts: int) -> str:
    if attempts <= 1:
        return ""
    return f" after {attempts} attempts"


def _post_codex_image_json(url: str, body: Dict[str, Any], timeout: int) -> Dict[str, Any]:
    auth = _load_codex_auth()
    if not auth:
        _die(f"Codex OAuth auth is missing. Expected {_codex_auth_file()}.")
    token, account_id = auth
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
        "Content-Type": "application/json",
        "originator": "editppt-image-cli",
        "User-Agent": "editppt-image-cli/0.1.0",
    }
    if account_id:
        headers["ChatGPT-Account-ID"] = account_id
    data = json.dumps(body, ensure_ascii=False).encode("utf-8")

    for attempt in range(DEFAULT_CODEX_MAX_RETRIES + 1):
        req = request.Request(
            url,
            data=data,
            method="POST",
            headers=headers,
        )
        try:
            with request.urlopen(req, timeout=timeout) as resp:
                text = resp.read(MAX_CODEX_RESPONSE_BYTES).decode("utf-8", errors="replace")
            break
        except error.HTTPError as exc:
            detail = exc.read(4096).decode("utf-8", errors="replace")
            if attempt < DEFAULT_CODEX_MAX_RETRIES and _should_retry_codex_http(exc.code):
                time.sleep(_codex_retry_delay(attempt + 1))
                continue
            attempts = attempt + 1
            raise RuntimeError(
                f"Codex Images request failed{_format_attempts(attempts)} "
                f"(HTTP {exc.code}): {detail}"
            ) from exc
        except (error.URLError, TimeoutError, socket.timeout) as exc:
            if attempt < DEFAULT_CODEX_MAX_RETRIES:
                time.sleep(_codex_retry_delay(attempt + 1))
                continue
            attempts = attempt + 1
            reason = getattr(exc, "reason", exc)
            raise RuntimeError(
                f"Codex Images request failed{_format_attempts(attempts)}: {reason}"
            ) from exc
    else:
        raise RuntimeError("Codex Images request failed after retry limit.")

    try:
        response = json.loads(text)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"Expected JSON Codex Images response, got: {text[:500]}") from exc
    if not isinstance(response, dict):
        raise RuntimeError("Expected JSON object Codex Images response.")
    return response


def _extract_codex_image_payloads(response: Dict[str, Any]) -> List[str]:
    error_obj = response.get("error")
    if isinstance(error_obj, dict):
        message = error_obj.get("message") or error_obj.get("code")
        raise RuntimeError(str(message or "Codex image generation failed."))
    data = response.get("data")
    if not isinstance(data, list):
        raise RuntimeError("Codex image response did not include a data array.")
    payloads: List[str] = []
    for item in data:
        if isinstance(item, dict) and isinstance(item.get("b64_json"), str):
            payloads.append(item["b64_json"])
    if not payloads:
        raise RuntimeError("No image payload found in Codex image response.")
    return payloads


def _runtime_python_path() -> str:
    return sys.executable


def _cli_reinstall_hint() -> str:
    return "`pipx install --force --editable <path-to-image-to-editable-ppt>/cli`"


def _dependency_hint(package: str, *, upgrade: bool = False) -> str:
    package_arg = f"-U {package}" if upgrade else package
    runtime_python = _runtime_python_path()
    return (
        "Install image-to-editable-ppt with pipx so CLI dependencies are installed, for example "
        f"{_cli_reinstall_hint()}, "
        f"or install {package} directly in this environment with `{runtime_python} -m pip install {package_arg}`."
    )


def _ensure_api_key(dry_run: bool) -> None:
    if os.getenv("OPENAI_API_KEY"):
        print(f"OPENAI_API_KEY is set. API target: {_api_target_label()}.", file=sys.stderr)
        return
    if dry_run:
        _warn(f"OPENAI_API_KEY is not set; dry-run only. API target: {_api_target_label()}.")
        return
    base_url = _api_base_url()
    model = _default_model()
    if base_url:
        command = (
            'editppt config --api-key "your-api-key" '
            f'--base-url "{base_url}" --model {model}'
        )
        target_hint = f"Detected third-party OpenAI-compatible API via OPENAI_BASE_URL={base_url}."
    else:
        command = f'editppt config --api-key "your-api-key" --model {model}'
        target_hint = "Detected official OpenAI API mode because OPENAI_BASE_URL is not set."
    _die(
        "Neither Codex OAuth nor OPENAI_API_KEY is available for editppt image generation.\n"
        f"{target_hint}\n"
        f"To use Codex OAuth, run `codex login` so {_codex_auth_file()} exists.\n"
        "To use a third-party OpenAI-compatible image API, configure ~/.editppt/config.yaml once:\n"
        f"  {command}\n"
        "To use a third-party proxy, set OPENAI_BASE_URL and the provider's model name."
    )


def _read_prompt(prompt: Optional[str], prompt_file: Optional[str]) -> str:
    if prompt and prompt_file:
        _die("Use --prompt or --prompt-file, not both.")
    if prompt_file:
        if prompt_file == "-":
            return sys.stdin.read().strip()
        path = Path(prompt_file)
        if not path.exists():
            _die(f"Prompt file not found: {path}")
        return path.read_text(encoding="utf-8").strip()
    if prompt:
        return prompt.strip()
    _die("Missing prompt. Use --prompt or --prompt-file.")
    return ""  # unreachable


def _check_image_paths(paths: Iterable[str]) -> List[Path]:
    resolved: List[Path] = []
    for raw in paths:
        path = Path(raw)
        if not path.exists():
            _die(f"Image file not found: {path}")
        if path.stat().st_size > MAX_IMAGE_BYTES:
            _warn(f"Image exceeds 50MB limit: {path}")
        resolved.append(path)
    return resolved


def _parse_size(size: str) -> Optional[Tuple[int, int]]:
    match = re.fullmatch(r"([1-9][0-9]*)x([1-9][0-9]*)", size)
    if not match:
        return None
    return int(match.group(1)), int(match.group(2))


def _validate_gpt_image_2_size(size: str) -> None:
    if size == "auto":
        return

    parsed = _parse_size(size)
    if parsed is None:
        _die("size must be auto or WIDTHxHEIGHT, for example 1024x1024.")

    width, height = parsed
    max_edge = max(width, height)
    min_edge = min(width, height)
    total_pixels = width * height

    if max_edge > GPT_IMAGE_2_MAX_EDGE:
        _die("GPT Image 2/2.5 size maximum edge length must be less than or equal to 3840px.")
    if width % 16 != 0 or height % 16 != 0:
        _die("GPT Image 2/2.5 size width and height must be multiples of 16px.")
    if max_edge / min_edge > GPT_IMAGE_2_MAX_RATIO:
        _die("GPT Image 2/2.5 size long edge to short edge ratio must not exceed 3:1.")
    if total_pixels < GPT_IMAGE_2_MIN_PIXELS or total_pixels > GPT_IMAGE_2_MAX_PIXELS:
        _die(
            "GPT Image 2/2.5 size total pixels must be at least 655,360 and no more than 8,294,400."
        )


def _validate_size(size: str, model: str) -> None:
    if _is_gpt_image_2_model(model):
        _validate_gpt_image_2_size(size)
        return

    if size not in ALLOWED_LEGACY_SIZES:
        _die(
            "size must be one of 1024x1024, 1536x1024, 1024x1536, or auto for this GPT Image model."
        )


def _validate_quality(quality: str, model: str) -> None:
    if quality not in ALLOWED_QUALITIES:
        _die("quality must be one of low, medium, high, xhigh, max, or auto.")
    if quality in {"xhigh", "max"} and not _is_gpt_image_2_5_model(model):
        _die("xhigh and max quality require gpt-image-2.5-flare or gpt-image-2.5-sunburst.")


def _validate_model(model: str) -> None:
    if GPT_IMAGE_MODEL_PREFIX not in model:
        _die(
            "model must be a GPT Image model name containing 'gpt-image-' "
            "(for example gpt-image-2, openai/gpt-image-2, gpt-image-1.5, "
            "gpt-image-1, or gpt-image-1-mini)."
        )


def _is_gpt_image_2_5_model(model: str) -> bool:
    return bool(re.fullmatch(
        r"gpt-image-2\.5-(?:flare|sunburst)(?:-\d{4}-\d{2}-\d{2})?",
        model.rsplit("/", 1)[-1],
    ))


def _is_gpt_image_2_model(model: str) -> bool:
    return bool(re.fullmatch(
        r"gpt-image-2(?:-\d{4}-\d{2}-\d{2})?", model.rsplit("/", 1)[-1]
    )) or _is_gpt_image_2_5_model(model)


def _build_output_paths(out: str) -> List[Path]:
    out_path = Path(out)
    if out_path.exists() and out_path.is_dir():
        return [out_path / f"image_1.{DEFAULT_OUTPUT_EXTENSION}"]

    if out_path.suffix == "":
        out_path = out_path.with_suffix(f".{DEFAULT_OUTPUT_EXTENSION}")
    return [out_path]


def _print_request(payload: dict) -> None:
    print(json.dumps(payload, indent=2, sort_keys=True))


def _decode_and_write(images: List[str], outputs: List[Path], force: bool) -> None:
    for idx, image_b64 in enumerate(images):
        if idx >= len(outputs):
            break
        if len(image_b64) > MAX_CODEX_BASE64_CHARS:
            _die("Image payload exceeded size limit.")
        out_path = outputs[idx]
        if out_path.exists() and not force:
            _die(f"Output already exists: {out_path} (use --force to overwrite)")
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_bytes(base64.b64decode(image_b64))
        print(f"Wrote {out_path}")


def _run_codex_image(
    *,
    prompt: str,
    image_paths: List[Path],
    mask_path: Optional[Path],
    args: argparse.Namespace,
    output_paths: List[Path],
    endpoint_label: str,
) -> bool:
    if not _codex_available():
        return False
    operation = "edit" if image_paths else "generate"
    body = _codex_image_body(
        prompt=prompt,
        image_paths=image_paths,
        mask_path=mask_path,
        model=args.model,
        size=args.size,
        quality=args.quality,
    )
    endpoint_url = _codex_image_url(operation)
    if args.dry_run:
        _print_request(
            {
                "backend": "codex-oauth",
                "endpoint": endpoint_url,
                "operation": operation,
                "outputs": [str(p) for p in output_paths],
                "auth_file": str(_codex_auth_file()),
                "image_model": args.model,
                "input_images": [str(p) for p in image_paths],
                "mask": str(mask_path) if mask_path else None,
                "size": args.size,
                "quality": args.quality,
                "background": body["background"],
            }
        )
        return True

    print(
        f"Calling Codex OAuth image backend ({endpoint_label}) with {len(image_paths)} input image(s).",
        file=sys.stderr,
    )
    started = time.time()
    response = _post_codex_image_json(endpoint_url, body, int(getattr(args, "timeout", DEFAULT_TIMEOUT)))
    payloads = _extract_codex_image_payloads(response)
    elapsed = time.time() - started
    print(f"Codex OAuth image completed in {elapsed:.1f}s.", file=sys.stderr)
    _decode_and_write(payloads, output_paths, force=args.force)
    return True


def _create_client():
    try:
        from openai import OpenAI
    except ImportError:
        _die(f"openai SDK not installed in the active environment. {_dependency_hint('openai')}")
    return OpenAI(
        api_key=os.getenv("OPENAI_API_KEY"),
        base_url=os.getenv("OPENAI_BASE_URL") or None,
    )


def _check_mask_path(mask: Optional[str]) -> Optional[Path]:
    if not mask:
        return None
    mask_path = Path(mask)
    if not mask_path.exists():
        _die(f"Mask file not found: {mask_path}")
    if mask_path.suffix.lower() != ".png":
        _warn(f"Mask should be a PNG with an alpha channel: {mask_path}")
    if mask_path.stat().st_size > MAX_IMAGE_BYTES:
        _warn(f"Mask exceeds 50MB limit: {mask_path}")
    return mask_path


def _generate(args: argparse.Namespace) -> None:
    prompt = _read_prompt(args.prompt, args.prompt_file)

    payload = {
        "model": args.model,
        "prompt": prompt,
        "size": args.size,
        "quality": args.quality,
    }
    output_paths = _build_output_paths(args.out)

    if args.dry_run:
        if _run_codex_image(
            prompt=prompt,
            image_paths=[],
            mask_path=None,
            args=args,
            output_paths=output_paths,
            endpoint_label="generate",
        ):
            return
        _print_request(
            {
                "backend": "openai-compatible-api",
                "endpoint": "/v1/images/generations",
                "outputs": [str(p) for p in output_paths],
                **payload,
            }
        )
        return

    if _run_codex_image(
        prompt=prompt,
        image_paths=[],
        mask_path=None,
        args=args,
        output_paths=output_paths,
        endpoint_label="generate",
    ):
        return

    print(
        "Calling Image API (generation). This can take up to a couple of minutes.",
        file=sys.stderr,
    )
    started = time.time()
    client = _create_client()
    result = client.images.generate(**payload)
    elapsed = time.time() - started
    print(f"Generation completed in {elapsed:.1f}s.", file=sys.stderr)

    images = [item.b64_json for item in result.data]
    _decode_and_write(images, output_paths, force=args.force)


def _edit(args: argparse.Namespace) -> None:
    prompt = _read_prompt(args.prompt, args.prompt_file)

    image_paths = _check_image_paths(args.image)
    mask_path = _check_mask_path(args.mask)

    payload = {
        "model": args.model,
        "prompt": prompt,
        "size": args.size,
        "quality": args.quality,
    }
    output_paths = _build_output_paths(args.out)

    if args.dry_run:
        if _run_codex_image(
            prompt=prompt,
            image_paths=image_paths,
            mask_path=mask_path,
            args=args,
            output_paths=output_paths,
            endpoint_label="edit",
        ):
            return
        payload_preview = dict(payload)
        payload_preview["image"] = [str(p) for p in image_paths]
        if mask_path:
            payload_preview["mask"] = str(mask_path)
        _print_request(
            {
                "backend": "openai-compatible-api",
                "endpoint": "/v1/images/edits",
                "outputs": [str(p) for p in output_paths],
                **payload_preview,
            }
        )
        return

    if _run_codex_image(
        prompt=prompt,
        image_paths=image_paths,
        mask_path=mask_path,
        args=args,
        output_paths=output_paths,
        endpoint_label="edit",
    ):
        return

    print(
        f"Calling Image API (edit) with {len(image_paths)} image(s).",
        file=sys.stderr,
    )
    started = time.time()
    client = _create_client()

    with _open_files(image_paths) as image_files, _open_mask(mask_path) as mask_file:
        request = dict(payload)
        request["image"] = image_files if len(image_files) > 1 else image_files[0]
        if mask_file is not None:
            request["mask"] = mask_file
        result = client.images.edit(**request)

    elapsed = time.time() - started
    print(f"Edit completed in {elapsed:.1f}s.", file=sys.stderr)
    images = [item.b64_json for item in result.data]
    _decode_and_write(images, output_paths, force=args.force)


def _open_files(paths: List[Path]):
    return _FileBundle(paths)


def _open_mask(mask_path: Optional[Path]):
    if mask_path is None:
        return _NullContext()
    return _SingleFile(mask_path)


class _NullContext:
    def __enter__(self):
        return None

    def __exit__(self, exc_type, exc, tb):
        return False


class _SingleFile:
    def __init__(self, path: Path):
        self._path = path
        self._handle = None

    def __enter__(self):
        self._handle = self._path.open("rb")
        return self._handle

    def __exit__(self, exc_type, exc, tb):
        if self._handle:
            try:
                self._handle.close()
            except Exception:
                pass
        return False


class _FileBundle:
    def __init__(self, paths: List[Path]):
        self._paths = paths
        self._handles: List[object] = []

    def __enter__(self):
        self._handles = [p.open("rb") for p in self._paths]
        return self._handles

    def __exit__(self, exc_type, exc, tb):
        for handle in self._handles:
            try:
                handle.close()
            except Exception:
                pass
        return False


def _add_shared_args(
    parser: argparse.ArgumentParser,
    *,
    include_prompt: bool = True,
    include_out: bool = True,
) -> None:
    parser.add_argument("--model", default=_default_model(), help="Requested image model. Defaults to IMAGE_TO_EDITABLE_PPT_IMAGE_MODEL or gpt-image-2.5-sunburst.")
    if include_prompt:
        parser.add_argument("--prompt", help="Prompt text. Use this or --prompt-file.")
        parser.add_argument("--prompt-file", help="Read prompt text from a file, or '-' for stdin.")
    parser.add_argument("--size", default=DEFAULT_SIZE, help="Output size such as auto or 2560x1440.")
    parser.add_argument("--quality", default=DEFAULT_QUALITY, help="Image quality: low, medium, high, xhigh, max, or auto (xhigh/max require GPT Image 2.5).")
    if include_out:
        parser.add_argument("--out", default=DEFAULT_OUTPUT_PATH, help="Output file for one image.")
    parser.add_argument("--force", action="store_true", help="Overwrite existing output files.")
    parser.add_argument("--dry-run", action="store_true", help="Validate arguments and show the selected backend without calling it.")
    parser.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT, help="Network timeout in seconds for Codex OAuth requests.")


def main() -> int:
    _load_runtime_env()
    parser = argparse.ArgumentParser(
        prog="editppt image",
        description="""Unified image generation/editing backend for editppt.

Use this command for generated images, image edits, clean bases, and foreground
asset sheets in image-to-editable-ppt runs.
""",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=IMAGE_HELP_EPILOG,
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    gen_parser = subparsers.add_parser(
        "generate",
        help="Create a new image",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=GENERATE_HELP_EPILOG,
    )
    _add_shared_args(gen_parser)
    gen_parser.set_defaults(func=_generate)

    edit_parser = subparsers.add_parser(
        "edit",
        help="Edit one or more images",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=EDIT_HELP_EPILOG,
    )
    _add_shared_args(edit_parser)
    edit_parser.add_argument("--image", action="append", required=True, help="Input image path. Repeat for multiple inputs.")
    edit_parser.add_argument("--mask", help="Optional mask image path.")
    edit_parser.set_defaults(func=_edit)

    args = parser.parse_args()
    _validate_model(args.model)
    _validate_size(args.size, args.model)
    _validate_quality(args.quality, args.model)
    if not _codex_available():
        _ensure_api_key(args.dry_run)

    args.func(args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
