#!/usr/bin/env python3
import argparse
import json
import subprocess
import sys
from pathlib import Path

from deck_run_state import load_deck, load_jobs, now_iso, run_dir_from_target, save_deck, save_jobs, set_run_status, sha256_file, write_json


SCRIPT_DIR = Path(__file__).resolve().parent


def run(command):
    print("+ " + " ".join(str(part) for part in command), flush=True)
    subprocess.run([str(part) for part in command], check=True)


def final_output_path(run_dir, deck):
    output = Path(deck.get("output", "final/deck_edited.pptx"))
    if output.is_absolute():
        return output
    return run_dir / output


def assert_pages_ready(run_dir, jobs):
    problems = []
    for page in jobs.get("pages", []):
        if page.get("status") not in {"recorded", "accepted"}:
            problems.append(f"{page['page_id']} status={page.get('status')}")
            continue
        result = page.get("result") or {}
        if result.get("validation_passed") is not True:
            problems.append(f"{page['page_id']} validation_passed={result.get('validation_passed')}")
        outputs = result.get("outputs") or {}
        hashes = result.get("hashes") or {}
        if not outputs or set(outputs) != set(hashes):
            problems.append(f"{page['page_id']} missing recorded output hashes; validate and record the page again")
            continue
        files = [(outputs[key], digest) for key, digest in hashes.items()]
        files.extend((result.get("asset_hashes") or {}).items())
        for relative_path, expected_hash in files:
            path = Path(run_dir) / relative_path
            if not path.is_file() or sha256_file(path) != expected_hash:
                problems.append(
                    f"{page['page_id']} recorded artifact changed or missing: {relative_path}; "
                    "repair affected outputs, validate and record the page again"
                )
    if problems:
        raise SystemExit("Pages are not ready for finalize:\n" + "\n".join(problems))


def main():
    parser = argparse.ArgumentParser(description="Build and validate the final editable PPTX from recorded pages.")
    parser.add_argument("run", help="Run directory or deck_manifest.json")
    args = parser.parse_args()

    run_dir = run_dir_from_target(args.run)
    deck = load_deck(run_dir)
    jobs = load_jobs(run_dir)
    assert_pages_ready(run_dir, jobs)

    out = final_output_path(run_dir, deck)
    out.parent.mkdir(parents=True, exist_ok=True)
    run([sys.executable, SCRIPT_DIR / "build_pptx_from_manifest.py", "--deck-manifest", run_dir / "deck_manifest.json", "--out", out])
    set_run_status(run_dir, "deck_built", "final pptx built")

    validation = out.parent / "validation.json"
    run([sys.executable, SCRIPT_DIR / "validate_pptx.py", out, "--deck-manifest", run_dir / "deck_manifest.json", "--report", validation])
    set_run_status(run_dir, "deck_validated", "final pptx validation passed")

    for page in jobs.get("pages", []):
        page["status"] = "accepted"
        page["accepted"] = True
        page["accepted_at"] = now_iso()
    jobs["run_status"] = "complete"
    jobs["updated_at"] = now_iso()
    save_jobs(run_dir, jobs)
    deck["completed_at"] = now_iso()
    save_deck(run_dir, deck)
    summary = {
        "schema_version": 1,
        "run_id": deck.get("run_id"),
        "status": "complete",
        "page_count": len(jobs.get("pages", [])),
        "output": str(out),
        "validation": str(validation),
        "completed_at": now_iso(),
    }
    write_json(out.parent / "run_summary.json", summary)
    set_run_status(run_dir, "complete", "final deck complete")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
